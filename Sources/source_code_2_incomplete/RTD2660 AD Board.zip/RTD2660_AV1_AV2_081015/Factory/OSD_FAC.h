//#if(_FACTORY_MENU_EN)
#define _OSD_FAC_

//void COsdFacHandler();
void DrawFactoryMenu(void);
void MFactoryProc(void);
void MFac9300Proc(void);
void MFacGainProc(void);
void MFac6500Proc(void);
void MFacOffsetProc(void);
extern void DrawFactoryMenu(void);
//#endif  //#ifdef __FAC_LCD_OSD__

//#endif  //#if(FACTORY_MENU_EN)
